﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;
[RequireComponent(typeof(Rigidbody2D))]
public class Player : MonoBehaviour {

	public float movement = 0f;
	public float movementSpeed = 10f;
	public GameObject leftBounds;
	public GameObject rightBounds;
	public float offset = 1.001f;

    //Scoring Elements
    public GameObject player;
    public Text scoreText;
    float playerPosY;
    int score;

	Rigidbody2D rb;

	// Use this for initialization
	void Start () {
		rb = GetComponent<Rigidbody2D> ();
		leftBounds = GameObject.Find ("LeftBounds");
		rightBounds = GameObject.Find ("RightBounds");

        //Score value
        score = 0;

        //Text value
        SetScoreText();

	}
	
	// Update is called once per frame
	void Update () {
		movement = Input.GetAxis ("Horizontal")*movementSpeed;

		Vector3 teleport = new Vector3 ((transform.position.x * (-1)) * offset, transform.position.y, transform.position.z);

		if (transform.position.x >= rightBounds.transform.position.x) {

			transform.position = teleport;
		}
		if (transform.position.x <= leftBounds.transform.position.x) {

			transform.position = teleport;
		}

        //Seting playerPosY for tracking purposes
        playerPosY = player.transform.position.y;
        
        //Update score
        if (playerPosY > score)
        {
            score = (int) playerPosY;
            SetScoreText();
        }
	}
	void FixedUpdate()
	{
		Vector2 velocity = rb.velocity;
		velocity.x = movement;
		rb.velocity = velocity;
	}

    void SetScoreText()
    {
        //Score based on strictly y value
        //scoreText.text = "Score: " + score.ToString();

        //Inflated score based on y value
        scoreText.text = "Score: " + score * 10;
    }
}
//new Vector3 (leftBounds.transform.position.x, rb.transform.position.y, rb.transform.position.z