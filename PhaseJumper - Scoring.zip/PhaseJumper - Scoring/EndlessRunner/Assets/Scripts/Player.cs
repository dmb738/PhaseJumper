﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
[RequireComponent(typeof(Rigidbody2D))]
public class Player : MonoBehaviour {

	public float movement = 0f;
	public float movementSpeed = 10f;
	public GameObject leftBounds;
	public GameObject rightBounds;
	public float offset = 1.001f;

	Rigidbody2D rb;

	// Use this for initialization
	void Start () {
		rb = GetComponent<Rigidbody2D> ();
		leftBounds = GameObject.Find ("LeftBounds");
		rightBounds = GameObject.Find ("RightBounds");
	}
	
	// Update is called once per frame
	void Update () {
		movement = Input.GetAxis ("Horizontal")*movementSpeed;

		Vector3 teleport = new Vector3 ((transform.position.x * (-1)) * offset, transform.position.y, transform.position.z);

		if (transform.position.x >= rightBounds.transform.position.x) {

			transform.position = teleport;
		}
		if (transform.position.x <= leftBounds.transform.position.x) {

			transform.position = teleport;
		}
	}

	void FixedUpdate()
	{
		Vector2 velocity = rb.velocity;
		velocity.x = movement;
		rb.velocity = velocity;
	}

}
//new Vector3 (leftBounds.transform.position.x, rb.transform.position.y, rb.transform.position.z