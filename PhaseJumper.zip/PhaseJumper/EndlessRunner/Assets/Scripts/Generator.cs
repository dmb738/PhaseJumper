﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Generator : MonoBehaviour {

	public GameObject platform;
	public Transform generationPoint;
	public float distanceBetween;

	// Use this for initialization
	void Start () {

	}
	
	// Update is called once per frame
	void Update () {
		if (transform.position.y < generationPoint.position.y) 
		{
			transform.position = new Vector3(Random.Range(-5.0f, 5.0f), Random.Range(0f, 2.0f) + distanceBetween, transform.position.z);
			distanceBetween += .8f;

			Instantiate (platform, transform.position, transform.rotation);
		}
	}
}
